// Install Dependencies
npm install

// Run App
npm start
OR
nodemon

------

FOR FRONT END
// Install Dependencies
npm install

// Run App
ng serve