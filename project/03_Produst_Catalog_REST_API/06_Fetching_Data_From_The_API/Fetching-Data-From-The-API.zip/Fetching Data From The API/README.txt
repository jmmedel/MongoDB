--You need to install the dependencies with

npm install

--Then run the app with

npm start

--If you have nodemon installed you can use that to start the app

nodemon