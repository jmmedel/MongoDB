// Install Dependencies
npm install

// Run server
npm start
