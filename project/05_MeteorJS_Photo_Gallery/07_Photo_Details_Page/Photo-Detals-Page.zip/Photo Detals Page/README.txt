-Intstall Dependencies with

meteor npm install

-Runn App

meteor