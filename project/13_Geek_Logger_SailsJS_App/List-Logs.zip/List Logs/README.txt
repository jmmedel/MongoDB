// Install Dependencies
npm install

// Run App
sails lift