// Install Dependencies
 npm install

 // Run App
 npm start
 OR
 nodemon