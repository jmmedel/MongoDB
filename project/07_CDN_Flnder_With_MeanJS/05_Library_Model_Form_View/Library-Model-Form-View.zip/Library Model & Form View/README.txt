Install dependencies
npm install

Run Server
grunt