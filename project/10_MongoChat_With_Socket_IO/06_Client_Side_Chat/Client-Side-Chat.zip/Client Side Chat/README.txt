// Install Dependencies
npm install

// Run server
npm start

// Open index.html file anywhere on your system